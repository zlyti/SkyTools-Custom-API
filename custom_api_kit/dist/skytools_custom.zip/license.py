"""
SkyTools License Verification Module
Vérifie la licence au démarrage et bloque le plugin si invalide.
"""

import json
import os
import hashlib
import uuid
import urllib.request
import urllib.error

from logger import logger

# Configuration
LICENSE_API_URL = "https://skytools-license.skytoolskey.workers.dev"
LICENSE_FILE = os.path.join(os.path.expanduser("~"), ".skytools_license")

# État global de la licence
_license_valid = False
_license_error = None


def get_hardware_id() -> str:
    """Génère un ID unique basé sur le matériel de l'ordinateur."""
    try:
        machine_id = ""
        
        # UUID de la machine
        try:
            machine_id += str(uuid.getnode())
        except:
            pass
        
        # Nom de l'ordinateur
        try:
            machine_id += os.environ.get('COMPUTERNAME', '')
        except:
            pass
        
        # Nom d'utilisateur
        try:
            machine_id += os.environ.get('USERNAME', '')
        except:
            pass
        
        hwid = hashlib.sha256(machine_id.encode()).hexdigest()[:16].upper()
        return hwid
    except Exception:
        return "UNKNOWN"


def load_saved_license() -> dict:
    """Charge les données de licence sauvegardées."""
    try:
        if os.path.exists(LICENSE_FILE):
            # Utiliser utf-8-sig pour gérer les fichiers avec ou sans BOM UTF-8
            with open(LICENSE_FILE, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load license file: {e}")
    return {}


def verify_license_online(key: str, hwid: str) -> dict:
    """Vérifie la licence auprès du serveur."""
    try:
        data = json.dumps({"key": key, "hwid": hwid}).encode('utf-8')
        req = urllib.request.Request(
            f"{LICENSE_API_URL}/plugin-check",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=10) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result
            
    except urllib.error.URLError as e:
        logger.warn(f"License server unreachable: {e}")
        return {"valid": False, "error": "NO_CONNECTION"}
    except Exception as e:
        logger.error(f"License verification failed: {e}")
        return {"valid": False, "error": "UNKNOWN"}


def check_license_at_startup() -> bool:
    """
    Vérifie la licence au démarrage du plugin.
    Retourne True si valide, False sinon.
    """
    global _license_valid, _license_error
    
    logger.log("SkyTools: Checking license...")
    
    # Charger la licence locale
    license_data = load_saved_license()
    
    if not license_data:
        logger.error("SkyTools: No license file found. Please run the installer first.")
        _license_valid = False
        _license_error = "NO_LICENSE"
        return False
    
    saved_key = license_data.get("key", "")
    saved_hwid = license_data.get("hwid", "")
    current_hwid = get_hardware_id()
    
    if not saved_key:
        logger.error("SkyTools: License file is empty.")
        _license_valid = False
        _license_error = "EMPTY_LICENSE"
        return False
    
    # Vérifier que le HWID local correspond
    if saved_hwid != current_hwid:
        logger.error("SkyTools: License HWID mismatch. This license is for another computer.")
        _license_valid = False
        _license_error = "HWID_MISMATCH_LOCAL"
        return False
    
    # Vérifier en ligne
    result = verify_license_online(saved_key, current_hwid)
    
    if result.get("valid"):
        logger.log("SkyTools: License valid!")
        _license_valid = True
        _license_error = None
        return True
    else:
        error = result.get("error", "UNKNOWN")
        logger.error(f"SkyTools: License invalid - {error}")
        _license_valid = False
        _license_error = error
        
        # Si la licence est invalide côté serveur, supprimer le fichier local
        if error in ["KEY_NOT_FOUND", "KEY_REVOKED", "HWID_MISMATCH", "HWID_BLOCKED"]:
            try:
                os.remove(LICENSE_FILE)
                logger.log("SkyTools: Removed invalid license file.")
            except:
                pass
        
        return False


def is_license_valid() -> bool:
    """Retourne l'état actuel de la licence."""
    return _license_valid


def get_license_error() -> str:
    """Retourne l'erreur de licence actuelle."""
    return _license_error or ""


def get_license_status() -> dict:
    """Retourne le statut complet de la licence."""
    return {
        "valid": _license_valid,
        "error": _license_error,
        "hwid": get_hardware_id()
    }

