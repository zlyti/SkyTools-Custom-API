-- 3684710's Lua and Manifest Created by Morrenus
-- My sexy Neighbour 2
-- Created: December 11, 2025 at 11:20:04 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3684710) -- My sexy Neighbour 2
-- MAIN APP DEPOTS
addappid(3684711, 1, "0b2ea915b88b5207d9cc94d94f2d85c33277b09ff15781326a589bd4f8ef4158") -- Depot 3684711
setManifestid(3684711, "5921584729154610998", 3567459606)